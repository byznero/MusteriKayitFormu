using System;
using System.IO;
using System.Security.Cryptography;
using System.Windows.Forms;
namespace soru2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Reset();
            saveFileDialog1.ShowDialog();
            string dosya = saveFileDialog1.FileName;
            if (dosya != null)
            {
                using (StreamWriter sw = new StreamWriter(dosya))
                {
                    sw.WriteLine(richTextBox1.Text);
                    MessageBox.Show("Dosya Kaydedildi");
                }
            }
            else
            {
                MessageBox.Show("Dosya Kaydedilemedi");
            }

            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            openFileDialog1.Reset();
            openFileDialog1.ShowDialog();
            string dosya = openFileDialog1.FileName;
            if (dosya != null)
            {
                using (StreamReader o = new StreamReader(dosya))
                {
                    string i�erik = o.ReadToEnd();
                    richTextBox1.Text = i�erik;
                }
            }
            else
            {
                MessageBox.Show("Dosya A��lamad�.");
            }
        }
        

    }
}
